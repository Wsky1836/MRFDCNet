from model.DABNet import DABNet


def build_model(model_name, num_classes):
    if model_name == 'MRFDCNet':
        return MRFDCNet(classes=num_classes)

from .camvid import *
from .cityscapes import *
